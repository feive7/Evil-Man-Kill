#version 330

// Input vertex attributes (from vertex shader)
in vec2 fragTexCoord;
in vec4 fragColor;
in vec3 fragPosition;
in vec3 fragNormal;

// Input uniform values
uniform sampler2D texture0;
uniform vec4 colDiffuse;
uniform vec3 viewPos;
uniform vec3 viewTarget;

// Output fragment color
out vec4 finalColor;
float fakelight(vec3 normal, vec3 direction) {
    float matcap = -dot(normal,direction);
    matcap = min(1.0,max(0.0,matcap));
    return matcap * 0.5 + 0.453;
}
// NOTE: Add your custom variables here
void main() {
    vec4 texelColor = texture(texture0, fragTexCoord);
    if(texelColor.a < 0.9) discard;

    // Direction from fragment to camera
    vec3 toView = normalize(viewTarget - viewPos);

    // Dot only based on angle (no distance factor)
    float light = fakelight(fragNormal, toView);

    finalColor = texelColor * colDiffuse * fragColor;
    finalColor.rgb *= light;
}